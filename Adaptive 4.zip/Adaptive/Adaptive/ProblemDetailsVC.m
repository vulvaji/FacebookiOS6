//
//  ProblemDetailsVC.m
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 21/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import "ProblemDetailsVC.h"

@interface ProblemDetailsVC ()

@end

@implementation ProblemDetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.pickerView.hidden=YES;
    
    _countryNames = @[@"Australia (AUD)", @"China (CNY)",
                      @"France (EUR)", @"Great Britain (GBP)", @"Japan (JPY)"];

    // Do any additional setup after loading the view.
}
#pragma mark -
#pragma mark PickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    return _countryNames.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    return _countryNames[row];
}


#pragma mark -
#pragma mark PickerView Delegate
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    
    
    NSString *resultString = [[NSString alloc] initWithFormat:
                              @" %@", _countryNames[row]];
    
    _resultLabel.text = resultString;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
  //  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
   // [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
   // [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    // return NO to disallow editing.
   
   
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    
    
    NSLog(@"textField ---- %ld",(long)textField.tag);
    
    if (textField.tag==1 ) {
        
        
        [UIView animateWithDuration:0.3 animations:^{
            CGRect f = self.view.frame;
            f.origin.y = 0.0f;;
            //NSLog(@"Here is the frame %@",f);
            self.view.frame = f;
        }];
    }else if(textField.tag==2){
        [UIView animateWithDuration:0.3 animations:^{
            CGRect f = self.view.frame;
            f.origin.y = 0.0f;;
            //NSLog(@"Here is the frame %@",f);
            self.view.frame = f;
        }];
    }
    else if(textField.tag==3){
        [UIView animateWithDuration:0.3 animations:^{
            CGRect f = self.view.frame;
            f.origin.y = -100;
            //NSLog(@"Here is the frame %@",f);
            self.view.frame = f;
        }];
    }else {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect f = self.view.frame;
            f.origin.y = -150;
            //NSLog(@"Here is the frame %@",f);
            self.view.frame = f;
        }];
    }
    NSLog(@"textFieldDidBeginEditing");
}// became first responder
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
    return YES;
    
}// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
- (void)textFieldDidEndEditing:(UITextField *)textField{
       NSLog(@"textFieldDidEndEditing");
}// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
- (void)textFieldDidEndEditing:(UITextField *)textField reason:(UITextFieldDidEndEditingReason)reason NS_AVAILABLE_IOS(10_0){
     NSLog(@"textFieldDidEndEditing  NS_AVAILABLE_IOS");
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = 0.0f;
        self.view.frame = f;
    }];
    
}// if implemented, called in place of textFieldDidEndEditing:

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
      NSLog(@"shouldChangeCharactersInRange");
    return YES;
    
}// return NO to not change text

- (BOOL)textFieldShouldClear:(UITextField *)textField{
      NSLog(@"textFieldShouldClear");
     return YES;
    
}// called when clear button pressed. return NO to ignore (no notifications)


#pragma mark - keyboard movements
- (void)keyboardWillShow:(NSNotification *)notification
{
    
    if (self.txtFld.tag!=1 || self.txtFld1.tag!=2) {
        
        
        [UIView animateWithDuration:0.3 animations:^{
            CGRect f = self.view.frame;
            f.origin.y = -70;
            //NSLog(@"Here is the frame %@",f);
            self.view.frame = f;
        }];
    }
   
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}



-(void)keyboardWillHide:(NSNotification *)notification
{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect f = self.view.frame;
        f.origin.y = 0.0f;
        self.view.frame = f;
    }];
}
-(IBAction)showPickr:(id)sender{
     self.pickerView.hidden=NO;
    
    
}
-(IBAction)hidePicker:(id)sender{
     self.pickerView.hidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
