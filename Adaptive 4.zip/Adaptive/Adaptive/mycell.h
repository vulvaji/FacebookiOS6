//
//  mycell.h
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 26/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mycell : UITableViewCell{
    
}

@property(nonatomic,retain) IBOutlet UILabel *lbl;
@property(nonatomic,retain) IBOutlet UILabel *lbl1;

@property(nonatomic,retain) IBOutlet UILabel *lbl2;


@end
