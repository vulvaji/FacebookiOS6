//
//  mycell.m
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 26/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import "mycell.h"

@implementation mycell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
