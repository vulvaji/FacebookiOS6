//
//  MyTableView.h
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 26/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mycell.h"
@class mycell;

@interface MyTableView : UITableViewController

@end
