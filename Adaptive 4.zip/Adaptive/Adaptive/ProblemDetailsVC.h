//
//  ProblemDetailsVC.h
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 21/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProblemDetailsVC : UIViewController{
    
}
@property (strong, nonatomic) NSArray *countryNames;

@property(nonatomic,retain)IBOutlet UIView *pickerView;
@property(nonatomic,retain)IBOutlet UILabel *resultLabel;

@property(nonatomic,retain)IBOutlet UITextField *txtFld;
@property(nonatomic,retain)IBOutlet UITextField *txtFld1;

-(IBAction)showPickr:(id)sender;
-(IBAction)hidePicker:(id)sender;
@end
