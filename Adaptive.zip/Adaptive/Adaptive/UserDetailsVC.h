//
//  UserDetailsVC.h
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 21/01/17.
//  Copyright © 2017 Verizon Business. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserDetailsVC : UIViewController

@end
