//
//  ViewController.m
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 01/11/1938 Saka.
//  Copyright © 1938 Saka Verizon Business. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
