//
//  ViewController.h
//  Adaptive
//
//  Created by VULVAJI SATYANARAYANA on 01/11/1938 Saka.
//  Copyright © 1938 Saka Verizon Business. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

