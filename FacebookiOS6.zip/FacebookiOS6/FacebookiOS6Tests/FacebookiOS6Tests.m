//
//  FacebookiOS6Tests.m
//  FacebookiOS6Tests
//
//  Created by www.iphoneicoding.com on 09/10/12.
//  Copyright (c) 2012 www.iphoneicoding.com. All rights reserved.
//

#import "FacebookiOS6Tests.h"

@implementation FacebookiOS6Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in FacebookiOS6Tests");
}

@end
