//
//  FacebookiOS6Tests.h
//  FacebookiOS6Tests
//
//  Created by www.iphoneicoding.com on 09/10/12.
//  Copyright (c) 2012 www.iphoneicoding.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface FacebookiOS6Tests : SenTestCase

@end
