//
//  ViewController.h
//  FacebookiOS6
//
//  Created by www.iphoneicoding.com on 09/10/12.
//  Copyright (c) 2012 www.iphoneicoding.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
@interface ViewController : UIViewController<FBLoginViewDelegate>
@property (strong, nonatomic) id<FBGraphUser> loggedInUser;
- (void)showAlert:(NSString *)message
           result:(id)result
            error:(NSError *)error;

- (IBAction)postStatusUpdateClick:(UIButton *)sender;
- (void) performPublishAction:(void (^)(void)) action;
- (IBAction)postPhotoClick:(UIButton *)sender ;
@end
