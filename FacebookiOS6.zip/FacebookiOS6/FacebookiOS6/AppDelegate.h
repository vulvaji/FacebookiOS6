//
//  AppDelegate.h
//  FacebookiOS6
//
//  Created by www.iphoneicoding.com on 09/10/12.
//  Copyright (c) 2012 www.iphoneicoding.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
